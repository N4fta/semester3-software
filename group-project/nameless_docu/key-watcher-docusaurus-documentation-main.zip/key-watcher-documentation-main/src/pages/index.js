import { Redirect } from 'react-router-dom'; // Import Redirect from react-router-dom

export default function Home() {
  return <Redirect to="/intro" />;

}
