---
sidebar_position: 2
sidebar_label: "Initial Display"
---

# Initial Display of the Dashboard

When you first open the dashboard, this is how it will appear: a clean and empty canvas ready for customization. 🎨

![ Initial Empty Display](img/initial_display.png)

Get started by adding widgets to make the dashboard your own! 🚀